# SocialBicycles (USA, Canada, Czech Republic, Poland)

[SocialBicycles](http://socialbicycles.com/) is JUMP's partership-based bikeshare program. They publish their [Data and APIs](https://app.socialbicycles.com/developer/#!/networks). This includes the following systems (cities) around the world:

* Atlanta, Boise, Charlottesville, Eugene, New Orleans, Orlando, Phoenix, Portland, Santa Monica, Tampa (USA)
* SoBi Hamilton (Hamilton, ON, CA)
* Velonet (Czech Republic)
* Wavelo (Warsaw, Poland)
* many more..
