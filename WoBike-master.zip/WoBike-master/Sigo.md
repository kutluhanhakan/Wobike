# Sigo
[Sigo](https://sigo.green) is a vehicle sharing service.

## Get Vehicle Locations

**URL**: `https://sigo.frontend.fleetbird.eu/api/prod/v1.06/cars/`

**Map URL**: `https://sigo.frontend.fleetbird.eu/api/prod/v1.06/map/cars/`

**Zone Locations?**: `https://sigo.frontend.fleetbird.eu/api/prod/v1.06/locations/`

**All Endpoints**: `https://sigo.frontend.fleetbird.eu/api/prod/v1.06/`
