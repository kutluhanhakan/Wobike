# Go Sharing
[Go Sharing](https://go-sharing.nl) is a scooter sharing service.

**Base URL**: `https://greenmo.core.gourban-mobility.com/front`

**Find Scooter Locations**: `https://greenmo.core.gourban-mobility.com/front/vehicles?lat=<Latitude>&lng=<Longitude>&rad=1000`

**Settings**: `https://greenmo.core.gourban-mobility.com/front/settings?keys=minimumRequiredAppVersion,support.methods,navigation,payment.methods,areas,booking,user.feedback,reservation.extension,user.accounts,errorhandling,user.requiredFields,logins,plugins.auth.google,app.main,screens.login,packages,theme,theme.splashScreen,theme.colors.main,theme.colors.main.dark,theme.colors.map,theme.colors.map.dark,map,map.clusterImage,rental,plugins.onesignal,plugins.activated,vehicles,tutorial,currency,qr.code,rewardStations,radar,additions.insurance`
