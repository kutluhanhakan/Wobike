# Zagster

List of all cities: https://zapi.zagster.com/api/v1/bikeshares/

For more information about bikes in a specific city, you'll need the city ID (found in `metadata["data"]["_id"]` from the above link)

List of stations in a city and station metadata: `https://zapi.zagster.com/api/v1/bikeshares/[City ID]/stations`

List of bikes in a city and bike metadata: `https://zapi.zagster.com/api/v1/bikeshares/[City ID]/bikes`
