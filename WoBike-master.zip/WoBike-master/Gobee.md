# Gobee Bike

Simple GET-Request example: `https://appaws.gobee.bike/GobeeBike/bikes/near_bikes?accuracy=20&lat=22.38&lng=114.198`
Alternative endpoint: `https://api.gobee.bike/`
