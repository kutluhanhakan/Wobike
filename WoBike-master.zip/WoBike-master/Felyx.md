# Felyx
[Felyx](https://felyx.com/) is a scooter sharing service that operates in Europe.

## Get Vehicle Locations

**URL**: `https://felyx.frontend.fleetbird.eu/api/prod/v1.06/cars/`

**Map URL**: `https://felyx.frontend.fleetbird.eu/api/prod/v1.06/map/cars/`

**City Locations**: `https://felyx.frontend.fleetbird.eu/api/prod/v1.06/locations/`

**Zones** `https://felyx.frontend.fleetbird.eu/api/prod/v1.06/territories/all/`

**All Endpoints**: `https://felyx.frontend.fleetbird.eu/api/prod/v1.06/`
