# Pony
[Pony](https://getapony.com/en) is an Bike/Scooter share hosting service

**Base URL**: `https://api.getapony.com`

## Get Vehicle Locations

**Path**: `/georegion/resolve`

**Method**: `GET`

**Parameters**:

| Parameters | Value                    | Mandatory |
| ---------- | ------------------------ | :-------: |
| latitude   | latitude                 | X         |
| longitude  | longitude                | X         |
