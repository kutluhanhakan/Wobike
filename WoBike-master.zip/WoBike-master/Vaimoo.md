# Vaimoo
[Vaimoo](https://vaimoo.com) is a scooter sharing service that operates in Denmark, Italy & Netherlands.

Active in 
* Copenhagen, Denmark: Copenhagen City Bike (Bycyklen) - https://bycyklen.dk
iOS: https://apps.apple.com/dk/app/bycyklen-copenhagen-bike-share/id1504234151
Android: https://play.google.com/store/apps/details?id=com.vaimoo.bycyklen
* Rotterdam, Netherlands (?)
* Statte, Italy: https://www.nexum.bike/stattebikesharing/ (looks like its stationary, without app)

API Base URL: https://rtm-aps-prod-we-api-01.azurewebsites.net
Copenhagen API Base URL: https://api-bycyklen.vaimoo.com

It looks that is mostly built with firebase: https://bikesharingprod.firebaseio.com
