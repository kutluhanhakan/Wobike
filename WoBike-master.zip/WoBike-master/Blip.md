# Blip
[Blip](https://www.blipscooters.com/) is a scooter sharing service that operates in New Zealand.

## Get Vehicle Locations

**URL**: `https://blip.frontend.fleetbird.eu/api/prod/v1.06/cars/`

**Map URL**: `https://blip.frontend.fleetbird.eu/api/prod/v1.06/map/cars/`

**Zone Locations?**: `https://blip.frontend.fleetbird.eu/api/prod/v1.06/locations/`

**All Endpoints**: `https://blip.frontend.fleetbird.eu/api/prod/v1.06/`
